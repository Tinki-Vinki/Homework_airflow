import os
import dill
import json
import pandas as pd
from datetime import datetime


def predict():
    path = os.environ.get('PROJECT_PATH', '..')
    with open(f'{path}/data/models/' + os.listdir(f'{path}/data/models')[0], 'rb') as file:
        best_model = dill.load(file)
    data = []
    for i in os.listdir(f'{path}/data/test'):
        with open(f'{path}/data/test/{i}', 'r') as f:
            df1 = pd.DataFrame(json.load(f), index=[0])
        data.append([df1.loc[0, 'id'], best_model.predict(df1)[0]])
        df2 = pd.DataFrame(data, columns=['id', 'predict'])
    return df2.to_csv(f'{path}/data/predictions/preds_{datetime.now().strftime("%Y%m%d%H%M")}.csv',index = False)


if __name__ == '__main__':
    predict()
